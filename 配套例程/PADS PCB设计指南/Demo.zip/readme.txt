cam:CAM文档定义的模板
dxf:结构图
library:封装库
macro:宏文件
other:GL850G HUB PCB
reuse:复用相关的文件
simple_power:原理图（PADS Logic格式）与PCB（PADS Layout格式）
simple_power_dsn:原理图（OrCAD格式）